# -*- encoding: utf-8 -*-

import pilas
import re
from pilas.interfaz.base_interfaz import BaseInterfaz

class EntradaDeTexto(BaseInterfaz):
    
    def __init__(self, texto_inicial="", x=0, y=0, ancho=300, limite_de_caracteres=20, icono=None, acepta_multilinea=True):
        BaseInterfaz.__init__(self, x=x, y=y)
        self.texto = texto_inicial
        self.cursor = ""
        self._cargar_lienzo(ancho)
        self.acepta_multilinea = acepta_multilinea

        if icono:
            self.icono = pilas.imagenes.cargar(icono)
        else:
            self.icono = None

        self.imagen_caja = pilas.imagenes.cargar(".Data/mensaje.png")
        self.centro = ("centro", "centro")
        self._actualizar_imagen()
        self.limite_de_caracteres = limite_de_caracteres
        self.cualquier_caracter()
        
        pilas.eventos.pulsa_tecla.conectar(self.cuando_pulsa_una_tecla)
        pilas.mundo.agregar_tarea_siempre(0.40, self._actualizar_cursor)
        self.fijo = True
        
    def _actualizar_cursor(self):
        if (self.tiene_el_foco):
            if self.cursor == "":
                self.cursor = "_"
            else:
                self.cursor = ""
        else:
            self.cursor = ""
            
        self._actualizar_imagen()
        return True

    def cualquier_caracter(self):
        self.caracteres_permitidos = re.compile(".*")

    def solo_numeros(self):
        self.caracteres_permitidos = re.compile("\d+")

    def solo_letras(self):
        self.caracteres_permitidos = re.compile("[a-z]+")
        
    def cuando_pulsa_una_tecla(self, evento):
        leermaximo=open(".Data/mensaje.txt","r")
        numeromaximo=int(leermaximo.read())
        leermaximo.close()
        if (self.tiene_el_foco and self.activo):
            if evento.codigo == '\x08' or evento.texto == '\x08':
                if numeromaximo == 0:
                    print "0"
                else:
                    numeromaximo = numeromaximo+1
                    escribirmaximo=open(".Data/mensaje.txt","w")
                    escribirmaximo.write(str(numeromaximo))
                    escribirmaximo.close()
                    print "1"
                self.texto = self.texto[:-1]
            elif str(evento.texto) == '\r' and self.acepta_multilinea:
                    self.texto += '\n'
                    numeromaximo = 0
                    escribirmaximo=open(".Data/mensaje.txt","w")
                    escribirmaximo.write(str(numeromaximo))
                    escribirmaximo.close()
                    print "2"
            else:
                if len(self.texto) < self.limite_de_caracteres:
                    if numeromaximo>=25:
                        self.texto += '\n'
                        self.texto = self.texto + evento.texto
                        numeromaximo=0
                        escribirmaximo=open(".Data/mensaje.txt","w")
                        escribirmaximo.write(str(numeromaximo))
                        escribirmaximo.close()
                        print "3"
                    else:
                        self.texto = self.texto + evento.texto
                        numeromaximo=numeromaximo+1
                        escribirmaximo=open(".Data/mensaje.txt","w")
                        escribirmaximo.write(str(numeromaximo))
                        escribirmaximo.close()
                        print "4"
            self._actualizar_imagen()
        
    def _cargar_lienzo(self, ancho):
        self.imagen = pilas.imagenes.cargar_superficie(ancho, 150)
        
    def _actualizar_imagen(self):
        ancho = self.imagen_caja.ancho()
        alto = self.imagen_caja.alto()
        self.imagen.pintar_parte_de_imagen(self.imagen_caja, 0, 0, 40, ancho, 0, 0)

        if self.icono:
            dx = 20
            self.imagen.pintar_parte_de_imagen(self.icono, 0, 0, 40, ancho, 7, 7)
        else:
            dx = 0

        for x in range(40, self.imagen.ancho() - 40):
            self.imagen.pintar_parte_de_imagen(self.imagen_caja, ancho - 40, 0, 40, alto, x, 0)

        self.imagen.texto(self.texto + self.cursor, 15 + dx, 20)
def inicializar():    
    inicializar=open(".Data/mensaje.txt","w")
    inicializar.write(str(0))
    inicializar.close()
