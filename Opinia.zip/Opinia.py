#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Importamos los modulos"""
import pilas
import sys
import Multilinea
import ConfigParser
import urllib

"""Creamos y Configuramos todas las funciones"""

def cuando_hacen_click():
    """Esta funcion es el evento que actuara cuando se haga click en el boton "Enviar" """

    
    """Capturamos y Guardamos los datos del Formulario"""
    pilas.avisar("Aguarde por favor, el formulario esta siendo enviado")
    cfgFile_w = open(".Data/datos.ini",'w')
    C.set('datos','nombre', txtNombre.texto)
    C.write(cfgFile_w)
    C.set('datos','email', txtEmail.texto)
    C.write(cfgFile_w)
    cfgFile_w.close()
    guardarmensaje = open(".Data/mensaje.txt","w")
    guardarmensaje.write(txtMensaje.texto)
    guardarmensaje.close()

    """Disparamos las funciones que enviara el email y otra que creara el archivo html, para luego ser subido por otra funcion"""
    enviar_email()
    bajar_html()

    """Ahora se limpiaran los campos y se reiniciara el formulario"""
    limpiar=open(".Data/datos.ini","w")
    limpiar.write("[datos]\nnombre = \nemail = \nasunto = \ncalificacion = ")
    limpiar.close()
    limpiar2=open(".Data/mensaje.txt","w")
    limpiar2.write("")
    limpiar2.close()
    txtNombre.texto = "Ingrese su Nombre"
    txtEmail.texto = "Ingrese su Email"
    txtMensaje.texto = u"Ingrese sus Comentarios"
    cuando_cambia_Calificacion(0)

    """Si todo ha sido procesado correctamente, notificamos la aceptacion"""
    pilas.avisar(u'Se envió el formulario')
    print u'Se envió el formulario Correctamente'


def cuando_selecciona_Asunto(opcion_seleccionada):
    """Esta funcion es el evento que actuara al seleccionar una alternativa del Campo de Opcion"""
    pilas.avisar("Ha seleccionado la opcion: " + opcion_seleccionada)
    cfgFile_w = open(".Data/datos.ini",'w')
    C.set('datos','asunto', opcion_seleccionada)
    C.write(cfgFile_w)
    cfgFile_w.close()
    return None

def cuando_cambia_Calificacion(valor):
    """Esta funcion es el evento que actua cuando se cambia el valor del Campo Deslizante """    
    lblCalificacionTotal.definir_texto(str(int(valor * 10)) +u' puntos')
    cfgFile_w = open(".Data/datos.ini",'w')
    C.set('datos','calificacion', str(int(valor * 10)) +u' puntos')
    C.write(cfgFile_w)
    cfgFile_w.close()

def bajar_html():
    """Esta funcion es la que descargara el archivo html del sitio web y luego se lo entregara a la fucion que lo preparara para luego subirlo"""    
    def reporthook(*a): print a

    C = ConfigParser.ConfigParser()
    C.read(".Data/conf.ini")
    web = C.get("SMTP","sitio-web")
    url = web+"Opiniones/Opiniones.html"
    file = ".Data/Opiniones.html"
    urllib.urlretrieve(url, file, reporthook)
    crear_html()

def crear_html():
    
    """Esta es la funcion que creara el informe HTML para luego ser subidos a la web"""

    from ftplib import FTP
    C.read(".Data/conf.ini")
    usuario = C.get("FTP","usuario")
    servidor = C.get("FTP","servidor")
    password = C.get("FTP","password")
    ftp = FTP(servidor);
    ftp.login(user=usuario, passwd=password)
    ftp.cwd("/public_html/Opiniones/");
    ftp.retrbinary("RETR Opiniones.html",open(".Data/Opiniones.html","wb").write)
    ftp.quit()

    """Cargamos los datos para crear el archivo html"""
    C.read(".Data/datos.ini")
    nombre = C.get("datos",'nombre')
    email = C.get("datos",'email')
    asunto = C.get("datos",'asunto')
    calificacion = C.get("datos",'calificacion')
    mensaje = open(".Data/mensaje.txt",'r')
    mensajea = mensaje.read()
    mensaje.close()

    """Guardamos el archivo html"""
    creararchivo = open(".Data/Opiniones.html","a")
    creararchivo.write(str("\n<hr>Nombre: "+nombre+"<br>Email: <a href=mailto:"+email+">"+email+"</a><br>Asunto: "+asunto+"<br>Calificacion: "+calificacion+"<br>Comentarios: "+mensajea))
    creararchivo.close()

    """Disparamos la funcion que subira el archivo html"""
    subir_html()

def enviar_email():
    """Esta es la funcion que enviara el email notificando de una nueva opinion"""

    """Importamos la libreria necesaria y cargamos los datos para luego ser enviados"""
    import smtplib
    C = ConfigParser.ConfigParser()
    C.read(".Data/datos.ini")
    nombre = C.get("datos","nombre")
    email = C.get("datos","email")
    asunto = C.get("datos","asunto")
    calificacion = C.get("datos","calificacion")
    cargarmensaje = open(".Data/mensaje.txt","r")
    mensaje=cargarmensaje.read()
    cargarmensaje.close()
    C.read(".Data/conf.ini")
    web = C.get("SMTP","sitio-web")
    email2 = C.get("SMTP","email")
    clave = C.get("SMTP","password")

    """Importamos los modulos adicionales necesarios"""
    from email.mime.text import MIMEText
    
    """Creamos el mensaje"""
    cuerpodelmensaje = str("Nombre: "+nombre+"\n"+"E-mail: "+email+"\n"+"Calificacion: "+calificacion+"\n"+"Comentarios: "+mensaje+"\n\nVer todos las Opiniones Recibidas\n"+web+"Opiniones/Opiniones.html")
    msg = MIMEText(cuerpodelmensaje)
 
    """Conectamos con el server"""
    msg['Subject'] = 'Usted ha recibido una nueva opinion - '+asunto
    msg['From'] = email
    msg['To'] = email2
     
    """Autenticamos"""
    mailServer = smtplib.SMTP('smtp.gmail.com',587)
    mailServer.ehlo()
    mailServer.starttls()
    mailServer.ehlo()
    mailServer.login(email2, clave)
     
    """Enviamos"""
    mailServer.sendmail(email2, email2, msg.as_string())
     
    """Cerramos conexion"""
    mailServer.close()

def subir_html():
    """Esta es la funcion que subira el archivo html al servidor web"""

    """Importamos las librerias necesarias"""
    import ftplib
    import os

    C.read(".Data/conf.ini") 
    """ Cargamos Datos FTP"""
    ftp_servidor = C.get("FTP","servidor")
    ftp_usuario  = C.get("FTP","usuario")
    ftp_clave    = C.get("FTP","password")
    ftp_raiz     = '/public_html/Opiniones/'
     
    """ Cargamos Datos del fichero a subir"""
    fichero_origen = '.Data/Opiniones.html'
    fichero_destino = 'Opiniones.html'
     
    """Conectamos con el servidor"""
    try:
	    s = ftplib.FTP(ftp_servidor, ftp_usuario, ftp_clave)
	    try:
	    	f = open(fichero_origen, 'r')
	    	s.cwd(ftp_raiz)
	    	s.storbinary('STOR ' + fichero_destino, f)
	    	f.close()
	    	s.quit()
	    except:
	    	print "No se ha podido encontrar el fichero " + fichero_origen
    except:
	    print "No se ha podido conectar al servidor " + ftp_servidor


"""Creamos la estructura basica del software"""

"""Inicializamos ConfigParser"""
C = ConfigParser.ConfigParser()
C.read(".Data/datos.ini")

"""Iniciamos Pilas"""
pilas.iniciar(titulo=u"Opinión Acerca de Camping Las Vertientes - Opinia")
fondo = pilas.fondos.Fondo(".Data/Camping.jpg")
fondo.escala = 1
posicionV = 10
posicionL = -170
posicionR = 30
lblEscala = 0.75
escapar = 500
Multilinea.inicializar()

""" Creamos el Boton"""
boton = pilas.interfaz.Boton("Enviar")
boton.x,boton.y = 150,-200

"""Convocamos el evento que actuara cuando se haga click en el boton"""  
boton.conectar(cuando_hacen_click)

"""Creamos y Configuramos Las Entradas de Texto"""
lblNombre = pilas.actores.Texto("Nombre:")
lblNombre.escala = lblEscala
lblNombre.x,lblNombre.y = posicionL,(posicionV *20)
txtNombre = pilas.interfaz.IngresoDeTexto(limite_de_caracteres=39, texto_inicial="Ingrese Su Nombre")
txtNombre.x,txtNombre.y = posicionR,(posicionV *20)
lblEmail = pilas.actores.Texto("E-mail:")
lblEmail.escala = lblEscala
lblEmail.x,lblEmail.y = posicionL,(posicionV *15)
txtEmail = pilas.interfaz.IngresoDeTexto(limite_de_caracteres=39, texto_inicial="Ingrese Su Email")
txtEmail.x,txtEmail.y = posicionR,(posicionV *15)

"""Creamos y Configuramos el Campo de Opcion"""
lblAsunto = pilas.actores.Texto("Asunto:")
lblAsunto.escala = lblEscala
lblAsunto.x,lblAsunto.y = posicionL,(posicionV *10)
opcionesAsunto = pilas.interfaz.ListaSeleccion(['Queja', 'Sugerencia','Contacto General'], cuando_selecciona_Asunto)
opcionesAsunto.x,opcionesAsunto.y = posicionR-100,(posicionV *10)

"""Creamos el campo Mensaje"""
lblMensaje = pilas.actores.Texto("Mensaje:")
lblMensaje.escala = lblEscala
lblMensaje.x,lblMensaje.y = posicionL,(posicionV *-5)
txtMensaje = Multilinea.EntradaDeTexto(limite_de_caracteres=235, texto_inicial=u"Ingrese sus Comentarios")
txtMensaje.x,txtMensaje.y = posicionR,(posicionV *-5)

"""Creamos y configuramos el Campo deslizante"""
lblCalificacion = pilas.actores.Texto(u"Calificación:")
lblCalificacion.escala = lblEscala
lblCalificacion.x,lblCalificacion.y = posicionL,(posicionV * 5)
lblCalificacionTotal = pilas.actores.Texto(u'0 puntos')
lblCalificacionTotal.escala = lblEscala
lblCalificacionTotal.x,lblCalificacionTotal.y = posicionL + 2 + lblCalificacion.ancho,(posicionV * 5)
Calificacion = pilas.interfaz.Deslizador()
Calificacion.conectar(cuando_cambia_Calificacion)
Calificacion.x,Calificacion.y = posicionR,posicionV*5

"""Ejecutamos el Programa"""
pilas.ejecutar()
